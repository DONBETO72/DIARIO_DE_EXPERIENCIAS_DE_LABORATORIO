﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();  

        /* La dferencia es que Console.Write escribe sin tomar en cuenta espacios o separaciones de líneas.
         * Console.WriteLine escribe el texto deseado y emplea una línea completa para esto. */
        Console.WriteLine   ("Hola Mundo");
        Console.WriteLine   ("Soy " + Nombre);
        Console.ReadKey();

        Console.Write("Hola mundo");
        Console.Write("soy " + Nombre);

    }
}