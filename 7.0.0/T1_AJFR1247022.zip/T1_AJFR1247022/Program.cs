﻿
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");

        /*EMPIEZAN DEFINICIÓN DE VARIABLES*/
        Console.WriteLine("Ingrese su nombre: ");
        string sNombre = Console.ReadLine();

        Console.WriteLine("Ingrese su edad: ");
        string sEdad = Console.ReadLine();

        Console.WriteLine("Ingrese su carreta: ");
        string sCarrera = Console.ReadLine();


        Console.WriteLine("Digite su carné");
        string sCarne = Console.ReadLine();

        /*EMPIEZA IMPRESIÓN DE PROGRAMA*/

        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carné: " + sCarne);
        Console.WriteLine(" ");

        Console.Write("Soy " + sNombre);
        Console.Write(" tengo " +sEdad );
        Console.Write(" años y estudio la carrera de " + sCarrera);
        Console.Write(". Mi ´número de carné es, " + sCarne);
            
    }
}